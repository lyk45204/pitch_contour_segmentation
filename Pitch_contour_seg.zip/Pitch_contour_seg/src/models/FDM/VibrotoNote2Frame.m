function VibrotoFrameVector = VibrotoNote2Frame(Vibrato,Frametime)
% input: Vibrato: [startTime endTime]

N_frame = length(Frametime);
VibrotoFrameVector = zeros(1,N_frame);
indicateSign = 1;

N_Vibrato = size(Vibrato,1);
for i = 1:N_Vibrato
    startTime = Vibrato(i,1);
    endTime = Vibrato(i,2);
    [v,N_frame_start] = min(abs(Frametime-startTime));
    [v,N_frame_end] = min(abs(Frametime-endTime));
    VibrotoFrameVector(N_frame_start:N_frame_end-1) = indicateSign;
end
