function data = FDMframetimeFn(data)

for i = 1:length(data)
        originalTime = data(i).OriPitch.time;
        f0Fs = 1/(originalTime(2)-originalTime(1));
        windowLengthTime = 0.125;  %window length in seconds
        windowLength = floor(windowLengthTime*f0Fs);
        stepOfWindow = 0.25;
        step = floor(windowLength*stepOfWindow);
        frameNum = ceil((length(originalTime)-windowLength)/step);
        timeF = zeros(frameNum,1);
        timeF(1) = windowLength/2/f0Fs + originalTime(1);
        for n = 2:frameNum
            timeF(n) = timeF(n-1) + step/f0Fs;
        end
        data(i).FDMframetime = timeF;
end