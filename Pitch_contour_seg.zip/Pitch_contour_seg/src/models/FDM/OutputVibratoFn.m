function [data, outputname] = OutputVibratoFn(data,Vibratos,PitchVersion,method,outputlevel)
% input: outputlevel: [1 1 1] (means output note, quantum and frame level),(1 means output, 0 means not);
% output: outputname is the filedname. 
% Vib_note, Vib_quantum, Vib_frame, 
global data;
outputname = strcat(PitchVersion,method);

for i = 1:length(data)
    if outputlevel(1) == 1
        data(i).VibratoDetResults.(outputname).Notelevel = Vibratos{i};
    end
    
    if outputlevel(2) == 1
        data(i).VibratoDetResults.(outputname).Quantumlevel = VibrotoNote2Frame(Vibratos{i},data(i).quantum.onset);
    end
    
    if outputlevel(3) == 1
        
        if isfield(data,'FDMframetime')
            frametime = data(i).FDMframetime;
        else
            frametime = data(i).F0time;
        end

        data(i).VibratoDetResults.(outputname).Framelevel = VibrotoNote2Frame(Vibratos{i},frametime);
        
    end
end


