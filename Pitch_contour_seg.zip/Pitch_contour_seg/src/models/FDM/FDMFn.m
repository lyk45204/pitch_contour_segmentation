function data = FDMFn(data,PitchVersion,vibratoRateLimit,vibratoExtentLimit, method)
global data;

data = PitchVersionSelectFn(data,PitchVersion);

Nfiles = length(data);
selectedTracks = [1:Nfiles];
N_totalTracks = length(selectedTracks);
Vibratos = cell(Nfiles,1);
%GETVIBRATO get the vibratos using FDM and plot vibratos
h = waitbar(0,'Vibrato detecting...');
i_th = 0; % count the tracks process
for i = selectedTracks
%     i
    i_th = i_th+1;
    progressFraction = i_th / N_totalTracks;

    waitbar(progressFraction, h, sprintf('%d%% Vibrato detecting...', round(progressFraction * 100)));
    
    %get the threshold for DT 
    freqThresh = vibratoRateLimit;
    ampThresh = vibratoExtentLimit;
    
    
    %Get vibratos using FDM method
    %vibratos: [vibrato start time:end time:duration]
%     [data(i).vibratos,~,data(i).FDMtime,data(i).FDMoutput] = vibratoDetectFunc(data(i).F0pitch,data(i).F0time,freqThresh,ampThresh);
    [Vibratos{i},~,~,~] = vibratoDetectFunc(data(i).F0pitch,data(i).F0time,freqThresh,ampThresh);
%     data(i).VibratoDetResults.(outputname) = [];
    %Get the individual vibrato time and pitch vector 
    %vibratosDetail:[time from 0 : pitch : orginal time]
%     data(i).vibratosDetail = getPassages(data(i).F0time,data(i).F0pitch,Vibratos,0);

    %----START of getting vibrato para-------
    %vibratosParaFDM: [vibrato rate:vibrato extent]
%     vibratosParaFDM = getVibratoParaFDM2( data(i).vibratos,data(i).FDMtime,data(i).FDMoutput );
%     %get vibrato rate, extent(using max-min method) vibrato sinusoid similarity for all passages
%     vibratoNames = fieldnames(data(i).vibratosDetail);
%     %vibratoParaMin: [rate, extent, std rate, std extent, SS]
%     vibratoParaMaxMin = zeros(length(vibratoNames),5);
%     vibratosSS = zeros(length(vibratoNames),1);
%     for ii = 1:length(vibratoNames)
%         vibratoTimePitch = getfield(data(i).vibratosDetail, char(vibratoNames(ii)));
%         %sinusoid similarity
%         vibratosSS(ii) = vibratoShape(vibratoTimePitch(:,[1,2]));
% 
%         vibratoParaMaxMin(ii,[1:4]) = vibratoRateExtent(vibratoTimePitch(:,[1,2]));
%         vibratoParaMaxMin(ii,5) = vibratosSS(ii);
%     end
%     %add sinusoid similarity to the vibratosParaFDM ([rate:extent:SS])        
%     vibratosParaFDM = [vibratosParaFDM,vibratosSS];
% 
%     %vibratosPara{1}from FDM
%     %vibratosPara{2}from Max-min
%     data(i).vibratoPara{1} = vibratosParaFDM;
%     data(i).vibratoPara{2} = vibratoParaMaxMin;
    %----END of getting vibrato para-------
end
close(h); % Close the waitbar when done
outputlevel = [1 0 1];
[data,outputname] = OutputVibratoFn(data,Vibratos,PitchVersion,method,outputlevel);     
    
%plot the vibratos on the pitch curve
% i_track = 1;
% figure();
% axePitch = axes('Position',[0.1 0.1 0.8 0.8]);
% plotPitch(data(i_track).F0time,data(i_track).F0pitch,axePitch);
% hold on;
% plotFeaturesArea(data(i_track).VibratoDetResults.(outputname).Notelevel,axePitch,'r');
% hold off;

end









    
    