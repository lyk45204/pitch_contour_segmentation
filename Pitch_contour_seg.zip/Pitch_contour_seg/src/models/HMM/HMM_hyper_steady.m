function bestSequence = HMM_hyper_steady(hiddenStates, hiddenStatesLabel, observations, initialProb, ...
    transitionProMatrix, emissionProDistribution, ...
    Max_scale_interval,Min_scale_interval)
    % Validate input dimensions and types
    % ... [Add any necessary input validation code here] ...

    % Number of hidden states and observations
    numStates = numel(hiddenStates);
    numObservations = size(observations,1);

    % Calculate the emission probability matrix
    emissionProMatrix = zeros(numStates, numObservations);
    for i = 1:numStates
        currentState = hiddenStates{i};
        currentStateEmissionDist = emissionProDistribution.(currentState);
        density = currentStateEmissionDist.density;
        X = currentStateEmissionDist.X; % feature 1 meshgrid
        Y = currentStateEmissionDist.Y; % feature 2 meshgrid
        
        for j = 1:numObservations
            currentObservation = observations(j,:);
            
            emissionProMatrix(i, j) = calculateDensityAtPoint(currentObservation(1), currentObservation(2), X, Y, density);
            % 衰减transitory's observation probbaility 
            % if extent is smaller than Max_scale_interval
            M = Max_scale_interval;% Your max scale interval value
            m = Min_scale_interval; % Your min scale interval value
            sigma = M - m;

            % Define the Gaussian decay function
            f_decay = @(extent) exp(-(extent - Max_scale_interval).^2 / (2*sigma^2));

            if (i==1) & (abs(currentObservation(2)) < Max_scale_interval)
                p = abs(currentObservation(2));
                emissionProMatrix(i, j) = emissionProMatrix(i, j).*f_decay(p);
            end
           

           


            % Check if the calculated density value is NaN
            if isnan(emissionProMatrix(i, j)) 
                error('NaN value detected at j = %d, currentObservation = [%f, %f]', j, currentObservation(1), currentObservation(2));
            end
            if emissionProMatrix(i, j)<0
                error('negative value detected at j = %d, currentObservation = [%f, %f]', j, currentObservation(1), currentObservation(2));
            end
        end

    end

    % Infer the best sequence of hidden states
    %Viterbi_decoder
    % input: init, transProb_array, obsProb, nState, nFrame, nTrans
    % output: the best path which contain state and pitch
   
    [bestSequence, p] = hmmViterbi_(emissionProMatrix, transitionProMatrix, initialProb); % use Mochen's code
    % Return the best sequence
    

end

function densityValue = calculateDensityAtPoint(xVal, yVal, X, Y, density)
    % Function to calculate the density at a given point (xVal, yVal)
    % using the provided density matrix and corresponding X and Y grids.
    
    
    % Interpolate the density matrix to find the density at (xVal,
    % yVal),extrapval set the outrange value is the min
    densityValue = interp2(X, Y, density, xVal, yVal, 'linear',min(density(:)));
end
