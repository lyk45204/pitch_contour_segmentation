% read data

clc; clear all; close all;
set(groot, 'defaultAxesFontSize', 18);
set(groot, 'defaultTextFontSize', 18);
set(groot, 'DefaultLineLineWidth', 2); % Sets the default line width to 2

% set parameters by observation from the quantum distribution
%% readAudio

filePathRoot = ['/Users/yukunli/Desktop/PhD/Projects/Quantum of pitch/Dataset/Steady/Erkomaishvili/Erkomaishvili_StableRegions/'];
AudioPath = strcat(filePathRoot,'Audio/');

global data;
DatasetName = 'Georgian Stable Region dataset';
data = readFileNameFn(AudioPath);
data = readAudioFn(AudioPath);

%% read segments of steady annotations
BasicSegPath = strcat(filePathRoot,'Segments/');
data = readSteadyRegionFn(BasicSegPath,data);

%% readF0 and preproscessing
data = readF0Fn(filePathRoot,2);
for i = 1:numel(data)
    indi = data(i).OriPitch.voicedIndicator;
    idx_unvoiced = find(indi == 0);
    time = data(i).OriPitch.time;
    pitch = data(i).OriPitch.pitch;
    time(idx_unvoiced) = [];
    pitch(idx_unvoiced) = [];
    pitch = midiToFreq(pitch);
    
    pitchtrack = [time pitch];

    filename = strcat(data(i).Filename,'.csv');
    savepath = strcat(filePathRoot,'F0_gap/');;  % Example save path

    % Concatenate the save path and the filename
    fullpath = fullfile(savepath, filename);

    % Save the 'pitchtrack' matrix to a CSV file at 'fullpath'
    dlmwrite(fullpath, pitchtrack, 'delimiter', ',', 'precision', 9);

    
end


%% readF0 and get multiple versions （unvoiced pitch indicator: 1 means no; 2 means have；3 means gap pitchtrack）
data = readMultiF0Fn( filePathRoot,3);

%% select a version of pitch trace
pitchversion = 'InterpoSmoothPitch';
data = PitchVersionSelectFn(data,pitchversion);

%% save data
SteadyTestData = data;
save('SteadyTestData.mat', 'SteadyTestData');

