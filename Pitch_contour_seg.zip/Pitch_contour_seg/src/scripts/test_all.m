%%%%%%%%%%%%%%%%%%%%% test using pitch contour segments dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% load data
load('ImportedData/testData.mat'); 

%% get pitchContourSegments using the functions used in training (ignore variable 'features' and 'labeled_quanta')
stateName = {'transitory', 'steady', 'modulation', 'noise'};
labels = {-1, 0, 1, -2};
[features, labeled_quanta] = extract_quantums_and_features(testData, stateName, labels); % include nosie state segment
pitchContourSegments = ExtractPitchContours(testData,labeled_quanta);

%% test the model's performance on detection of three states together (mean of correct proportion of detection of each pitch contour)
testSet = pitchContourSegments;
[performance_frame_mean, performance_frame_var] = validateHMM(transitionMatrix, observationLikelihoods, testSet);


function [features, quanta] = extract_quantums_and_features(data, stateNames, labels)

transitory_cutoff = 1;%Hz 
steady_cutoff = 200; %Hz
vibrato_cutoff = 20; % Hz

    features = struct();
    quanta = struct('file', {}, 'state', {}, 'pitchtrack', {}, ...
        'onset', {}, 'offset', {}, 'dur', {}, 'pitchinterval', {}, 'fre', {}, 'extent', {});
    label_to_state = containers.Map(labels, stateNames);

    for i_files = 1:length(data)
        annotated_segments = data(i_files).State;
        file_pitchtrack = [data(i_files).F0time data(i_files).F0pitch];
        label_vector = annotated_segments(:,2); % -1, 0, 1, -2
        quantum_index = 1;

        for i_seg = 1:size(annotated_segments, 1)

            seg_onset = annotated_segments(i_seg, 1);
            seg_dur = annotated_segments(i_seg, 3);
            seg_offset = seg_onset + seg_dur;
            seg_pitchtrack = cell2mat(cutpitch(seg_onset, seg_offset, file_pitchtrack));
            CurLabel = label_vector(i_seg);

            % Determine the quantums in the segment
            switch CurLabel
                case -1 % transitory
                    num_quantums = 1;
                
                    quantum_onset = seg_onset;
                    quantum_offset = seg_offset; 
                    quantum_dur = seg_dur;
                    quantum_pitchtrack = seg_pitchtrack;


                    dur = quantum_dur;
                    pitchinterval = quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2);
                    fre = 1./(quantum_dur*2);
                    extent = pitchinterval./2;
                    if fre > transitory_cutoff %Hz
                        quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                            'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                            'dur', dur, 'pitchinterval', pitchinterval, 'fre', fre, 'extent', extent);
                        quanta(end+1) = quantum;
                    end

                case 0
                    MinPeakDistance = 0;
                    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
                    extremums_time = extremums(:,1);
                    num_quantums = size(extremums,1)-1;

                    for i_quantum = 1:num_quantums
                        % Extract features and details for each quantum
                        quantum_onset = extremums_time(i_quantum);
                        quantum_offset = extremums_time(i_quantum+1);
                        quantum_dur = quantum_offset - quantum_onset;
                        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

                        dur = quantum_dur;
                        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
                        fre = 1./(quantum_dur*2);
                        extent = pitchinterval./2;

                        if fre < steady_cutoff %Hz
                       
                            % Assign quantum details in a more concise manner
                            quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                                'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                                'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                            quanta(end+1) = quantum;
                        end
                       
                    end
                case 1
                    MinPeakDistance = 0;
                    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
                    extremums_time = extremums(:,1);
                    num_quantums = size(extremums,1)-1;

                    for i_quantum = 1:num_quantums
                        % Extract features and details for each quantum
                        quantum_onset = extremums_time(i_quantum);
                        quantum_offset = extremums_time(i_quantum+1);
                        quantum_dur = quantum_offset - quantum_onset;
                        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

                        dur = quantum_dur;
                        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
                        fre = 1./(quantum_dur*2);
                        extent = pitchinterval./2;

                        if fre < vibrato_cutoff % Hz

                            % Assign quantum details in a more concise manner
                            quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                                'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                                'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                            quanta(end+1) = quantum;
                        end
                        

                    end
                case -2 % no quantum segmentation
                    num_quantums = 1;
                
                    quantum_onset = seg_onset;
                    quantum_offset = seg_offset; 
                    quantum_dur = seg_dur;
                    quantum_pitchtrack = seg_pitchtrack;

                    dur = [];
                    pitchinterval = [];
                    fre = [];
                    extent = [];
                    
                    quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                        'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                        'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                    quanta(end+1) = quantum;
            end
        end

    end

    for i_quantum = 1:length(quanta)

        state = quanta(i_quantum).state;
        quantum_feature = [quanta(i_quantum).dur quanta(i_quantum).extent];
        %quantum_feature = [log(quanta(i_quantum).fre) quanta(i_quantum).extent];
            % Update features structure
            if ~strcmp(label_to_state(CurLabel),'noise')
                if isfield(features, state)
                    features.(state) = [features.(state); quantum_feature];
                else
                    features.(state) = quantum_feature;
                end
            end
        end
    
        %%%%%%%%%%%% add transition mode between quantums based on pitch continuity%%%%
        % transition mode: 1 means current can transit to the next, 0 means
        % no
        % 寻找所有 'file' 字段值为 i_files 的 quantum
    for i_files = 1:length(data)
        
        indices = find([quanta.file] == i_files);
        N_quantum = length(indices);
        for i_quantum = 1:N_quantum-1
            
            if strcmp( quanta(indices(i_quantum)).state,'noise') | strcmp( quanta(indices(i_quantum+1)).state,'noise')
                quanta(indices(i_quantum)).transition = 0;
            else
         

                CurOffset = quanta(indices(i_quantum)).offset;
                NextOnset = quanta(indices(i_quantum+1)).onset;

                % get the onset and offset of each gap between two segments
                GapOnset = CurOffset;
                GapOffset = NextOnset;
                pitchtrackOri = [data(i_files).OriPitch.time data(i_files).OriPitch.pitch];
                Gapdur = GapOffset - GapOnset;
                switch sign(Gapdur)
                    case 1 % Gapdur>0

                        % get the pitch track in the gap region
                        GapPitch = cutpitch(GapOnset,GapOffset,pitchtrackOri);
                        GapPitch = cell2mat(GapPitch);
                        % check if pitchtrack is continous
                        if size(GapPitch,1)>1
                            Gap_t = GapPitch(:,1);
                            if any(diff(Gap_t)>0.006) % there is a silence
                                quanta(indices(i_quantum)).transition = 0;
                            else
                                quanta(indices(i_quantum)).transition = 1;

                            end
                        else
                            quanta(indices(i_quantum)).transition = 1;
                        end
                       
                    otherwise % Gapdur<=0
                        quanta(indices(i_quantum)).transition = 1;
                end
            end
        end
        quanta(indices(end)).transition = 0;

    end
end


function pitchContourSegments = ExtractPitchContours(data,quanta)
    % Initialize the output structure
    pitchContourSegments = struct('F0time', {}, 'F0pitch', {}, 'Quantum', {}, 'QuantumNum', {}, 'Filename', {});

    % Process each file in the data
    for fileIdx = 1:length(data)
        fileIdx
        F0originalTime = data(fileIdx).OriPitch.time;

        F0time = data(fileIdx).F0time;
        F0pitch = data(fileIdx).F0pitch;
        % Find indices of quanta that belong to the specified file
        indices = find([quanta.file] == fileIdx);
        % Extract those quanta of the current file
        quantumData = quanta(indices);
        filename = data(fileIdx).Filename;

        % Find breaks in F0time to identify pitch contour segments
        delta_time = F0originalTime(2)-F0originalTime(1);
        breaks_Ori = find(diff(F0originalTime) > 1.2*delta_time);
        breaks_Time_end = F0originalTime(breaks_Ori);
        breaks_Time_start = F0originalTime(breaks_Ori+1);
        % set noises region as breaks
        noiseIndices = find(arrayfun(@(x) strcmp(x.state, 'noise'), quantumData));
        if ~isempty(noiseIndices)
            noise_quantum_onset = quantumData(noiseIndices).onset;
            noise_quantum_offset = quantumData(noiseIndices).offset;
            breaks_Time_end = [breaks_Time_end;noise_quantum_onset];
            breaks_Time_start = [breaks_Time_start;noise_quantum_offset];
        end



        breaks_loc_start = zeros(length(breaks_Time_start),1);
        breaks_loc_end = zeros(length(breaks_Time_end),1);

        for i_breaks = 1:length(breaks_loc_start)
            [v_min,breaks_loc_start(i_breaks)] = min( abs(breaks_Time_start(i_breaks)-F0time) );
            [v_min,breaks_loc_end(i_breaks)] = min( abs(breaks_Time_end(i_breaks)-F0time) );

        end

        segmentStarts = sort([1; breaks_loc_start]);
        segmentEnds = sort([breaks_loc_end; length(F0time)]);

        % Create segments
        for i_segment = 1:length(segmentStarts)
            i_segment
            startIdx = segmentStarts(i_segment); % ind of F0
            endIdx = segmentEnds(i_segment);
            
            % Initialize segment
            segment = struct();
            segment.F0time = F0time(startIdx:endIdx);
            segment.F0pitch = F0pitch(startIdx:endIdx);
            segment.Quantum = struct();
            segment.Filename = filename;

            % Find quanta within this segment's time range
            segmentStartTime = F0time(startIdx);
            segmentEndTime = F0time(endIdx);

            if ~isempty(quantumData)
                % Initialize segment.Quantum with the same fields as the first quantumData
                segment.Quantum = quantumData(1);
                segment.Quantum(1) = []; % Clear the initial content
            else
                error('no quantum in the segment %d in file %d',i_segment,fileIdx)
            end
            
            for j = 1:length(quantumData)
                quantumOnset = quantumData(j).onset;
                quantumOffset = quantumData(j).offset;

                if ~strcmp(quantumData(j).state,'noise' ) && ...
                        ((quantumOnset >= segmentStartTime && quantumOnset <= segmentEndTime) || ...
                        (quantumOffset >= segmentStartTime && quantumOffset <= segmentEndTime))
                    segment.Quantum(end+1) = quantumData(j);
                    
                end
            end
            segment.QuantumNum = length(segment.Quantum);

            % update the boundary of F0time and F0pitch of the pitch
            % contour to remove the silence region.
            if segment.QuantumNum>0
                quanta_in_seg = segment.Quantum;
                onset = quanta_in_seg(1).onset;
                offset = quanta_in_seg(end).offset;

                F0time_seg = segment.F0time;
                F0pitch_seg = segment.F0pitch;

                if F0time_seg(1)<onset
                    [~, onsetIdx] = min(abs(F0time_seg - onset));
                    F0time_seg = F0time_seg(onsetIdx:end);
                    F0pitch_seg = F0pitch_seg(onsetIdx:end);
                end
                if F0time_seg(end)>offset
                    [~, offsetIdx] = min(abs(F0time_seg - offset));
                    F0time_seg = F0time_seg(1:offsetIdx);
                    F0pitch_seg = F0pitch_seg(1:offsetIdx);
                end

                segment.F0time = F0time_seg;
                segment.F0pitch = F0pitch_seg;
            end

            % Append to output structure
            if segment.QuantumNum > 0 % ignore the silent pitch contour segment without annotation
                pitchContourSegments(end+1) = segment;
            end

        end
    end

   

    % Check if any pitchContourSegments share the same quantum region
    % If yes, display an error and show the numbers of the pitchContours and the shared state

    numSegments = length(pitchContourSegments);

    for i = 1:numSegments-1
%         i
            % Get the state regions for the current pair of segments
            Quantum_i = pitchContourSegments(i).Quantum;
            Quantum_j = pitchContourSegments(i+1).Quantum;

            % Check for shared states
            if Quantum_i(end).onset == Quantum_j(1).onset
                error('Shared Quantum found between segments %d and %d in file %d', i, i+1,fileIdx);
            end

    end

    
end