% read data

clc; clear all; close all;
set(groot, 'defaultAxesFontSize', 18);
set(groot, 'defaultTextFontSize', 18);
set(groot, 'DefaultLineLineWidth', 2); % Sets the default line width to 2

% set parameters by observation from the quantum distribution
%% readAudio
filePathRoot = ['/Users/yukunli/Desktop/PhD/Projects/Quantum of pitch/Dataset/Vibrato/test/'];
AudioPath = strcat(filePathRoot,'Audio/');

global data;
DatasetName = 'Yang Vibrato dataset';
data = readFileNameFn(AudioPath);
data = readAudioFn(AudioPath);

%% read segments of steady, vibrato, transitory and noises annotations
BasicSegPath = strcat(filePathRoot,'Segments/');
data = readVibratoFn(BasicSegPath,data); % (onset offset)


%% readF0 and get multiple versions （unvoiced pitch indicator: 1 means no; 2 means have；3 means gap pitchtrack）
data = readMultiF0Fn( filePathRoot,3);

%% select a version of pitch trace
pitchversion = 'InterpoSmoothPitch';
data = PitchVersionSelectFn(data,pitchversion);

%% save data
% testData = data;
VibratoTestData = data;
save('VibratoTestData.mat', 'VibratoTestData');

