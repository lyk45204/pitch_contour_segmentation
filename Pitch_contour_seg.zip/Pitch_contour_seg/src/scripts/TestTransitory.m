%%%%%%%%%%%%%%%%%%%%% test using transitory segments dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all; clear all;
%% read TransitoryTestData.mat
load('TransitoryTestData.mat'); 
testData = TransitoryTestData; % include TransitorySeg (onset offset duration)


%% Extract Pitch Contours including quantums with labels(no 'noise' and remove the silence region)
labelname = 'TransitorySeg';
[pitchContourSegments,num_silent_label] = ExtractPitchContours_no_quanta(testData,labelname);

%% test the model's performance on detection of three states together (mean of correct proportion of detection of each pitch contour)
testSet = pitchContourSegments;

% Load the variables from the file
HMM_KDE_Para = load('HMM_KDE_Para.mat');

% Access paras from the loaded data
transitionMatrix = HMM_KDE_Para.transitionMatrix;
observationLikelihoods = HMM_KDE_Para.observationLikelihoods;

%% evaluation
testState = 'transitory';
[performance_frame, performance_state,validationSet] = validate_portamento_stateHMM(transitionMatrix, observationLikelihoods, testSet, testState);

