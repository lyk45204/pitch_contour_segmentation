%%%%%%%%%%%%%%%%%%%%% test using steady segments dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all; clear all;
%% read TransitoryTestData.mat
load('SteadyTestData.mat'); 
testData = SteadyTestData; % include TransitorySeg (onset offset duration)


%% Extract Pitch Contours including quantums with labels(no 'noise' and remove the silence region)
labelname = 'StableRegions';
[pitchContourSegments,num_silent_label] = ExtractPitchContours_no_quanta(testData,labelname);

%% test the model's performance on detection of three states together (mean of correct proportion of detection of each pitch contour)
testSet = pitchContourSegments;

% Load the variables from the file
HMM_KDE_Para = load('HMM_KDE_Para.mat');

% Access paras from the loaded data
transitionMatrix = HMM_KDE_Para.transitionMatrix;
observationLikelihoods = HMM_KDE_Para.observationLikelihoods;

%% evaluation
testState = 'steady';
% Ablation Experiments
% 定义模块数量
num_modules = 3;
% 生成所有可能的组合的数量
num_combinations = 2^num_modules;
% 初始化AblationSwitch矩阵
AblationSwitch = zeros(num_combinations, num_modules);
% 生成所有可能的组合
AblationSwitch = [
    1 1 1; % 所有模块都开启
    1 1 0; % 去除一个模块
    1 0 1; % 去除一个模块
    0 1 1; % 去除一个模块
    1 0 0; % 去除两个模块
    0 1 0; % 去除两个模块
    0 0 1; % 去除两个模块
    0 0 0  % 所有模块都关闭
];

% selected_combinations = [1:8];
selected_combinations = [7];

performance_frame_output = [];
performance_state_output = [];

for i_combinations = selected_combinations
% for i_combinations = 1:num_combinations
    i_combinations
    Cur_AblationSwitch = AblationSwitch(i_combinations,:);
    [performance_frame, performance_state,validationSet,output] = validate_steady_stateHMM( ...
        transitionMatrix, observationLikelihoods, testSet, testState, Cur_AblationSwitch);
    
    clear output;
    clear validationSet;
    if i_combinations == selected_combinations(1)
        performance_frame_output = performance_frame.metrics;
        performance_frame_output = [performance_frame_output;num2cell(performance_frame.mean)];
    else
        performance_frame_output = [performance_frame_output;num2cell(performance_frame.mean)];
    end

    performance_state_key = performance_state.performance_state_key;

    if i_combinations == selected_combinations(1)
        performance_state_output = performance_state_key(:,1)';
        performance_state_output = [performance_state_output;(performance_state_key(:,2)')];
    else
        performance_state_output = [performance_state_output;(performance_state_key(:,2)')];
    end



end











