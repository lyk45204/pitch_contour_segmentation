%%%%%%%%%%%%%%%%%%%%% test using transitory segments dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all; clear all;
%% read TransitoryTestData.mat
load('VibratoTestData.mat'); 
testData = VibratoTestData; % include TransitorySeg (onset offset duration)


%% Extract Pitch Contours including quantums with labels(no 'noise' and remove the silence region)
labelname = 'VibratoSeg';
[pitchContourSegments,num_silent_label] = ExtractPitchContours_no_quanta(testData,labelname);

%% test the model's performance on detection of three states together (mean of correct proportion of detection of each pitch contour)
testSet = pitchContourSegments;

% Load the variables from the file
HMM_KDE_Para = load('HMM_KDE_Para.mat');

% Access paras from the loaded data
transitionMatrix = HMM_KDE_Para.transitionMatrix;
observationLikelihoods = HMM_KDE_Para.observationLikelihoods;

%% test using FDM
load('VibratoFDMTestData.mat'); 
vibratoRateLimit = [4,9];
vibratoExtentLimit = [0.15, inf];
PitchVersion = 'OriPitch';
data = VibratoFDMTestData;
method = 'FDM'
% just use the original voiced pitch
data = FDMFn(data,PitchVersion,vibratoRateLimit,vibratoExtentLimit, method);
%% evaluation
% FDM
n_files = numel(data);
groundTruth_frame_cell = cell(n_files,1);transcribed_frame_cell = cell(n_files,1);
groundTruth_state_cell = cell(n_files,1); transcribed_state_cell = cell(n_files,1);
for i_file = 1:numel(data)
    transcribed_frame_cell{i_file} = data(i_file).VibratoDetResults.OriPitchFDM.Framelevel;
    transcribed_state_cell{i_file} = data(i_file).VibratoDetResults.OriPitchFDM.Notelevel;
    groundTruth_state_cell{i_file} = data(i_file).VibratoSeg;
    groundTruth_frame_cell{i_file} = VibrotoNote2Frame(groundTruth_state_cell{i_file},data(i_file).F0time);
end

[performance_frame_FDM, performance_state_FDM] = validate_FDMvibrato_stateHMM( ...
groundTruth_frame_cell,transcribed_frame_cell,groundTruth_state_cell,transcribed_state_cell);
%% my
testState = 'modulation';
[performance_frame, performance_state,performance_Post_frame,performance_Post_state,validationSet] = validate_vibrato_stateHMM(transitionMatrix, observationLikelihoods, testSet, testState);



