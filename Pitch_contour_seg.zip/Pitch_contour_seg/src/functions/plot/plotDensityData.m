function plotDensityData(observationLikelihoods, data, stateName, plotData)
    % Validate if the specified state exists in observationLikelihoods
    % plotData is a switcher of plot data
    if ~isfield(observationLikelihoods, stateName)
        error('Specified state does not exist in observation likelihoods.');
    end

    % Extract the density, X, and Y values for the specified state
    density = observationLikelihoods.(stateName).density;
    X = observationLikelihoods.(stateName).X;
    Y = observationLikelihoods.(stateName).Y;

    % Plot the density

    % 设置图形背景为白色
    set(gcf, 'color', 'white');

    % 设置坐标轴为黑色
    set(gca, 'color', 'white', 'XColor', 'black', 'YColor', 'black', 'ZColor', 'black');


    surf(X, Y, density, 'LineStyle', 'none');
    view(40, 35); % 固定视角，您可以调整这里的值以匹配示例图像的角度
    colormap("parula");
    hold on;
    alpha(.8);

    % Optionally plot the data points
    if plotData
        plot(data(:,1), data(:,2), 'w.', 'MarkerSize', 10);
    end

    grid on; % 打开网格
    box on; % 绘制图形边框

    % Add labels and title
    xlabel('Duration/s');
    ylabel('Extent/semitone');
    
    % Capitalize the first letter of the state name
    stateName(1) = upper(stateName(1));
    title(sprintf('Observation Probability Density Function for %s State', stateName));
    xlim([min(X(:)) max(X(:))]); % 设置X轴的范围为数据的最小和最大值
    ylim([min(Y(:)) max(Y(:))]); % 设置Y轴的范围为数据的最小和最大值

    % Turn off hold
    hold off;
end
