function data = readTransitoryFn(filePath,data)
% input: M : onset, offset, duration
% output: onset offset duration
global data;
fileInf = dir2(filePath);
 %% ignore folders and DS_Store file
    IgnoreFiles = [];
    n_files = length(fileInf);
    for i = 1:n_files
        if strcmp(fileInf(i).name,'.DS_Store')
            IgnoreFiles = [IgnoreFiles;i];
            
        end
        if fileInf(i).isdir
            IgnoreFiles = [IgnoreFiles;i];

        end

    end
    fileInf([IgnoreFiles]) = [];
%% read

n_files = length(fileInf);
for i_files = 1:n_files
    fileNameSuffix = fileInf(i_files).name;
    if isnumeric(fileNameSuffix) == 0
        fullPathName = strcat(filePath,fileNameSuffix);
        [filepath,name,extension] = fileparts(fullPathName);
        [TransitorySeg] = readmatrix(fullPathName); % onset offset duration
        
        % change duration to statelabel
        TransitorySeg(:,3) = -1;
      
        data(i_files).TransitorySeg = TransitorySeg;
        
    end
end