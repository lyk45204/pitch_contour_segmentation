function [performance_frame, performance_state,performance_Post_frame,performance_Post_state,validationSet] = validate_vibrato_stateHMM(transitionMatrix, observationLikelihoods, validationSet,testState)
% just evaluate individual state detection performance

% testState is to set which state to test ('transitory', 'steady', 'modulation')

% initilization
num_contour = numel(validationSet);

% Extract all filenames from the structure
allFilenames = {validationSet.Filename};
% Find the unique filenames
uniqueFilenames = unique(allFilenames);
% Count the number of unique filenames
numUniqueFilenames = length(uniqueFilenames);


transcribed_state_cell = cell(numUniqueFilenames,1); % each cell contains the state-level transitories of a file
groundTruth_state_cell = cell(numUniqueFilenames,1);
transcribed_Post_state_cell = cell(numUniqueFilenames,1); % each cell contains the state-level transitories of a file

transcribed_frame_cell = cell(numUniqueFilenames,1); 
groundTruth_frame_cell = cell(numUniqueFilenames,1); 
transcribed_Post_frame_cell = cell(numUniqueFilenames,1); 

FrameMetrics = zeros(numUniqueFilenames,5);
% Initialize 'previousFile' variable before the loop starts
previousFile = '';
i_file = 0;



for i_contour = 1:num_contour
    i_contour

    % cut quantum
    contour_seg = validationSet(i_contour);
    F0time_seg = contour_seg.F0time;
    F0pitch_seg = contour_seg.F0pitch;

    seg_pitchtrack = [F0time_seg F0pitch_seg];

    quanta = struct('file', {}, 'state', {}, 'pitchtrack', {}, 'onset', {}, 'offset', {}, ...
        'dur', {}, 'pitchinterval', {}, 'fre', {}, 'extent', {});
    %%
    MinPeakDistance = 0;
   
    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
    extremums_time = extremums(:,1);
    num_quantums = size(extremums,1)-1;
    QuantumSeg_matrix = [];

    observation_seq = [];

    onset_list = [];
    offset_list = [];
    dur_list = [];
    pitchInterval_list = [];
    pitchStart_list = [];
    for i_quantum = 1:num_quantums
        % Extract features and details for each quantum
        quantum_onset = extremums_time(i_quantum);
        quantum_offset = extremums_time(i_quantum+1);
        quantum_dur = quantum_offset - quantum_onset;
        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

        dur = quantum_dur;
        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
        fre = 1./(quantum_dur*2);
        extent = pitchinterval./2;

        % Assign quantum details in a more concise manner
        quantum = struct('file', contour_seg.Filename, 'state', 0, ...
            'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
            'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
        quanta(end+1) = quantum;
        QuantumSeg_matrix = [QuantumSeg_matrix; quantum.onset quantum.offset];
         

        % get the observation sequence of this pitch contour
        observation_seq = [observation_seq; dur extent];
    end

   




    % QuantumSeg_struct(i_quantum).quantum.onset = quantum.onset;
    %     QuantumSeg_struct(i_quantum).quantum.offset = quantum.offset;
    %     QuantumSeg_struct(i_quantum).quantum.dur = quantum.dur;

    % HMM segmentation: quantum-level detection
    hiddenStates = {'transitory', 'steady', 'modulation'};
    hiddenStatesLabel = {-1, 0, 1};

    hiddenLabel2State = containers.Map(hiddenStatesLabel, hiddenStates);
    hiddenState2Label = containers.Map(hiddenStates, hiddenStatesLabel);
    numStates = numel(hiddenStates);
    initialProb = repmat(1/numStates,numStates,1);
    bestSequence = HMM(hiddenStates, hiddenStatesLabel, observation_seq, initialProb, transitionMatrix, observationLikelihoods);
    bestSequence = bestSequence - 2;    
    for i_quantum = 1:num_quantums
        validationSet(i_contour).QauntumEstimate(i_quantum).state = hiddenLabel2State(bestSequence(i_quantum)); 
    end


    %% convert quantum level inferred states to frame level and state level
    testStateLabel = hiddenState2Label(testState);
    % state-level DT
    QuantumSeg_matrix = [QuantumSeg_matrix bestSequence'];
    Mer_QuantumSeg_matrix = mergeQuantumSegments(QuantumSeg_matrix);

    idx_TrState_QuantumSeg_matrix = find(Mer_QuantumSeg_matrix(:,3)==testStateLabel);
    TrStateSeg_matrix = Mer_QuantumSeg_matrix(idx_TrState_QuantumSeg_matrix,:);
    validationSet(i_contour).TrStateSeg = TrStateSeg_matrix;

    % frame-level DT: frame not labeled with detected state has value 0 
    ContourTimeStamp = validationSet(i_contour).F0time;
    validationSet(i_contour).TrFrame = convertToFrameLevel(TrStateSeg_matrix, ContourTimeStamp);
    
    %% finetune
    quantumCriterion = 3; %the frame criterion for the vibrato candidates, make it larger or equal to a number consecutive frames.
    Vibratostemp = validationSet(i_contour).TrStateSeg;
    if ~isempty(Vibratostemp)
        validationSet(i_contour).TrPostStateSeg = Post_Vibrato_Intonation(QuantumSeg_matrix,quanta, quantumCriterion);
        % frame-level DT: frame not labeled with detected state has value 0
        ContourTimeStamp = validationSet(i_contour).F0time;
        validationSet(i_contour).TrPostFrame = convertToFrameLevel(validationSet(i_contour).TrPostStateSeg, ContourTimeStamp);
    else
        validationSet(i_contour).TrPostStateSeg = [];
        validationSet(i_contour).TrPostFrame = validationSet(i_contour).TrFrame;
    end
    
    %% ground truth
    % state-level ground truth   
    validationSet(i_contour).GTStateSeg = validationSet(i_contour).labelRegion;
    GTStateSeg_matrix = validationSet(i_contour).GTStateSeg;

    % frame-level ground truth
    ContourTimeStamp = validationSet(i_contour).F0time;
    validationSet(i_contour).GTFrame = convertToFrameLevel(GTStateSeg_matrix, ContourTimeStamp);

   
    % resemble detections of pitch contours into file level to avoid some contour
    % without annotation
    currentFile = validationSet(i_contour).Filename;

    % frame_level metrics
    groundTruth_frame = validationSet(i_contour).GTFrame;
    transcribed_frame = validationSet(i_contour).TrFrame;
    transcribed_Post_frame = validationSet(i_contour).TrPostFrame;


    % state_level metrics
    transcribed_state = validationSet(i_contour).TrStateSeg; %(onset offset statelabel)
    groundTruth_state = validationSet(i_contour).GTStateSeg;
    transcribed_Post_state = validationSet(i_contour).TrPostStateSeg;

    if ~isempty(transcribed_state)
        transcribed_state(:,3) = 88; % make it as a pitch number to fit molina's toolbox
    end
    if ~isempty(transcribed_Post_state)
        transcribed_Post_state(:,3) = 88; % make it as a pitch number to fit molina's toolbox
    end
    if ~isempty(groundTruth_state)
        groundTruth_state(:,3) = 88; % make it as a pitch number to fit molina's toolbox
    end

    % resemble
    if i_contour == 1 || ~strcmp(currentFile, previousFile)
        % New file encountered or first iteration
        i_file = i_file + 1; % Move to the next file
        transcribed_frame_cell{i_file} = transcribed_frame;
        groundTruth_frame_cell{i_file} = groundTruth_frame;
        transcribed_Post_frame_cell{i_file} = transcribed_Post_frame;
        
        transcribed_state_cell{i_file} = transcribed_state;
        groundTruth_state_cell{i_file} = groundTruth_state;
        transcribed_Post_state_cell{i_file} = transcribed_Post_state;
    else
        % Current contour belongs to the same file as the previous contour
        if ~isempty(transcribed_frame)
            transcribed_frame_cell{i_file} = [transcribed_frame_cell{i_file}; transcribed_frame];     
        end
        if ~isempty(transcribed_Post_frame)
            transcribed_Post_frame_cell{i_file} = [transcribed_Post_frame_cell{i_file}; transcribed_Post_frame];
        end
        if ~isempty(groundTruth_frame)
            groundTruth_frame_cell{i_file} = [groundTruth_frame_cell{i_file}; groundTruth_frame];
        end

        if ~isempty(transcribed_state)
            transcribed_state_cell{i_file} = [transcribed_state_cell{i_file}; transcribed_state];
        end
        if ~isempty(transcribed_Post_state)
            transcribed_Post_state_cell{i_file} = [transcribed_Post_state_cell{i_file}; transcribed_Post_state];
        end
        if ~isempty(groundTruth_state)
            groundTruth_state_cell{i_file} = [groundTruth_state_cell{i_file}; groundTruth_state];
        end

    end


    % Update 'previousFile' for the next iteration
    previousFile = currentFile;


end

%% groundTruth VS transcribed
for i_file = 1:length(groundTruth_frame_cell)
    groundTruth_frame = groundTruth_frame_cell{i_file}(:,2);
    transcribed_frame = transcribed_frame_cell{i_file}(:,2);

    [accuracy_nor, accuracy_SD, precision, recall, F1Score] = calculateFrameMetrics(groundTruth_frame, transcribed_frame);
    FrameMetrics(i_file,:) = [accuracy_nor, accuracy_SD, precision, recall, F1Score];
end

% Define metric names as a cell array
FrameMetricsName = {'Accuracy1', 'Accuracy2', 'Precision', 'Recall', 'F-Measure'};
performance_frame_mean = mean(FrameMetrics);
performance_frame_var = var(FrameMetrics);

performance_frame = struct();
performance_frame.metrics = FrameMetricsName;
performance_frame.mean = performance_frame_mean;
performance_frame.var = performance_frame_var;


% state level
[performance_state_all,performance_state_key]=evaluation_pitch_contour(transcribed_state_cell,groundTruth_state_cell);
performance_state = struct();
performance_state.performance_state_all = performance_state_all;
performance_state.performance_state_key = performance_state_key;


%% groundTruth VS transcribed_Post
for i_file = 1:length(groundTruth_frame_cell)
    i_file
    groundTruth_frame = groundTruth_frame_cell{i_file}(:,2);
    transcribed_Post_frame = transcribed_Post_frame_cell{i_file}(:,2);

    [accuracy_nor, accuracy_SD, precision, recall, F1Score] = calculateFrameMetrics(groundTruth_frame, transcribed_Post_frame);
    FrameMetrics_Post(i_file,:) = [accuracy_nor, accuracy_SD, precision, recall, F1Score];
end

% Define metric names as a cell array
FrameMetricsName = {'Accuracy1', 'Accuracy2', 'Precision', 'Recall', 'F-Measure'};
performance_Post_frame_mean = mean(FrameMetrics_Post);
performance_Post_frame_var = var(FrameMetrics_Post);

performance_Post_frame = struct();
performance_Post_frame.metrics = FrameMetricsName;
performance_Post_frame.mean = performance_Post_frame_mean;
performance_Post_frame.var = performance_Post_frame_var;


% state level
[performance_Post_state_all,performance_Post_state_key]=evaluation_pitch_contour(transcribed_Post_state_cell,groundTruth_state_cell);
performance_Post_state = struct();
performance_Post_state.performance_Post_state_all = performance_Post_state_all;
performance_Post_state.performance_Post_state_key = performance_Post_state_key;

end

function StateSeg_matrix = mergeQuantumSegments(QuantumSeg_matrix)
    % Initialize the output matrix with the first row of the input matrix
    StateSeg_matrix = QuantumSeg_matrix(1,:);
    
    if size(QuantumSeg_matrix, 1)>1
        % Iterate through the QuantumSeg_matrix
        for i = 2:size(QuantumSeg_matrix, 1)
            currentSeg = QuantumSeg_matrix(i,:);
            lastSeg = StateSeg_matrix(end,:); % the one previous the current quantum

            % Check if the current segment can be merged with the last segment
            if currentSeg(3) == lastSeg(3)
                % Merge segments: Update the offset of the last segment
                StateSeg_matrix(end, 2) = currentSeg(2);
            else
                % Different state label, so add the current segment as a new row
                StateSeg_matrix = [StateSeg_matrix; currentSeg];
            end
        end
    end
end

function Frame_matrix = convertToFrameLevel(StateSeg_matrix, ContourTimeStamp)
    % Initialize Frame_matrix
    Frame_matrix = zeros(length(ContourTimeStamp), 2);
    
    % Assign time values to the first column of Frame_matrix
    Frame_matrix(:, 1) = ContourTimeStamp;
    
    % Iterate through each timestamp
    if ~isempty(StateSeg_matrix)
        for i = 1:length(ContourTimeStamp)
            currentTime = ContourTimeStamp(i);

            % Find the segment that the current time belongs to
            for j = 1:size(StateSeg_matrix, 1)
                if currentTime >= StateSeg_matrix(j, 1) && currentTime <= StateSeg_matrix(j, 2)
                    Frame_matrix(i, 2) = StateSeg_matrix(j, 3); % Assign statelabel
                    break; % Exit the loop once the segment is found
                end
            end
        end
    end
end