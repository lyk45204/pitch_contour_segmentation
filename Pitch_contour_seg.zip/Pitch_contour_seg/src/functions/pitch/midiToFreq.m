function [frequencies] = midiToFreq(midiNotes)
%MIDITOFREQ Convert MIDI note numbers to frequencies
% Input:
%   @midiNotes: MIDI note numbers
% Output:
%   @frequencies: in Hz

    midiNotesSize = size(midiNotes);
    frequencies = zeros(midiNotesSize);
    for i = 1:midiNotesSize(1)
        for j = 1:midiNotesSize(2)
            if(midiNotes(i,j) <= 0)
                frequencies(i,j) = 0; % Zero or negative MIDI numbers are not valid, set to 0 Hz
            else
                frequencies(i,j) = 440 * 2^((midiNotes(i,j) - 69) / 12);
            end
        end
    end
end
