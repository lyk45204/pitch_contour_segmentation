function [performance_frame, performance_state] = validate_FDMvibrato_stateHMM( ...
    groundTruth_frame_cell,transcribed_frame_cell,groundTruth_state_cell,transcribed_state_cell)


for i_file = 1:length(groundTruth_frame_cell)
    groundTruth_frame = groundTruth_frame_cell{i_file}(:);
    transcribed_frame = transcribed_frame_cell{i_file}(:);

    [accuracy_nor, accuracy_SD, precision, recall, F1Score] = calculateFrameMetrics(groundTruth_frame, transcribed_frame);
    FrameMetrics(i_file,:) = [accuracy_nor, accuracy_SD, precision, recall, F1Score];
end

% Define metric names as a cell array
FrameMetricsName = {'Accuracy1', 'Accuracy2', 'Precision', 'Recall', 'F-Measure'};
performance_frame_mean = mean(FrameMetrics);
performance_frame_var = var(FrameMetrics);

performance_frame = struct();
performance_frame.metrics = FrameMetricsName;
performance_frame.mean = performance_frame_mean;
performance_frame.var = performance_frame_var;


% state level
[performance_state_all,performance_state_key]=evaluation_pitch_contour(transcribed_state_cell,groundTruth_state_cell);
performance_state = struct();
performance_state.performance_state_all = performance_state_all;
performance_state.performance_state_key = performance_state_key;