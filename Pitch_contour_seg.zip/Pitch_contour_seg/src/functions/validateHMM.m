function [performance_frame_mean, performance_frame_var, confusionMatrix,performance_state_all,performance_state_key] = validateHMM(transitionMatrix, observationLikelihoods, validationSet)

set(groot, 'defaultAxesFontSize', 18);
set(groot, 'defaultTextFontSize', 18);
set(groot, 'DefaultLineLineWidth', 2); 

num_contour = numel(validationSet);
proportionCorrect = zeros(num_contour,1);
groundTruth_frame_all = [];
transcribed_frame_all = [];
Tr_quantum_length = 3; % the threshold of smallest number of quantum of modulation region 

for i_contour = 1:num_contour
    % cut quantum
    contour_seg = validationSet(i_contour);
    F0time_seg = contour_seg.F0time;
    F0pitch_seg = contour_seg.F0pitch;

    seg_pitchtrack = [F0time_seg F0pitch_seg];

    quanta = struct('file', {}, 'state', {}, 'pitchtrack', {}, 'onset', {}, 'offset', {}, ...
        'dur', {}, 'pitchinterval', {}, 'fre', {}, 'extent', {});
    MinPeakDistance = 0;
    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
    extremums_time = extremums(:,1);
    num_quantums = size(extremums,1)-1;
    QuantumSeg_matrix = [];

    observation_seq = [];
    for i_quantum = 1:num_quantums
        % Extract features and details for each quantum
        quantum_onset = extremums_time(i_quantum);
        quantum_offset = extremums_time(i_quantum+1);
        quantum_dur = quantum_offset - quantum_onset;
        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

        dur = quantum_dur;
        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
        fre = 1./(quantum_dur*2);
        extent = pitchinterval./2;

        % Assign quantum details in a more concise manner
        quantum = struct('file', contour_seg.Filename, 'state', 0, ...
            'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
            'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
        quanta(end+1) = quantum;
        QuantumSeg_matrix = [QuantumSeg_matrix; quantum.onset quantum.offset];

        % get the observation sequence of this pitch contour
        observation_seq = [observation_seq; dur extent];
    end

    validationSet(i_contour).QauntumEstimate = quanta;


    % HMM segmentation: quantum-level detection
    hiddenStates = {'transitory', 'steady', 'modulation'};
    hiddenStatesLabel = {-1, 0, 1};
    hiddenLabel2State = containers.Map(hiddenStatesLabel, hiddenStates);
    hiddenState2Label = containers.Map(hiddenStates, hiddenStatesLabel);


    numStates = numel(hiddenStates);
    initialProb = repmat(1/numStates,numStates,1);
    bestSequence = HMM(hiddenStates, hiddenStatesLabel, observation_seq, initialProb, transitionMatrix, observationLikelihoods);
    bestSequence = bestSequence - 2;

    bestSequence = correctShortModulated(bestSequence,Tr_quantum_length); % change short modulated as transitory
    for i_quantum = 1:num_quantums
        validationSet(i_contour).QauntumEstimate(i_quantum).state = hiddenLabel2State(bestSequence(i_quantum)); 
    end


    %% convert quantum level to frame level and state level
    % state-level DT
    QuantumSeg_matrix = [QuantumSeg_matrix bestSequence'];
    TrStateSeg_matrix = mergeQuantumSegments(QuantumSeg_matrix);
    validationSet(i_contour).TrStateSeg = TrStateSeg_matrix;

    % frame-level DT
    ContourTimeStamp = validationSet(i_contour).F0time;
    validationSet(i_contour).TrFrame = convertToFrameLevel(TrStateSeg_matrix, ContourTimeStamp);

    % state-level ground truth
    GTquanta = validationSet(i_contour).Quantum;
    num_quanta = numel(GTquanta);
    GTQuantumSeg_matrix = zeros(num_quanta,3);
    for i_quanta = 1:num_quanta
        GTQuantumSeg_matrix(i_quanta,1) = GTquanta(i_quanta).onset;
        GTQuantumSeg_matrix(i_quanta,2) = GTquanta(i_quanta).offset;
        GTQuantumSeg_matrix(i_quanta,3) = hiddenState2Label(GTquanta(i_quanta).state);
    end
    
    GTStateSeg_matrix = mergeQuantumSegments(GTQuantumSeg_matrix);
    validationSet(i_contour).GTStateSeg = GTStateSeg_matrix;

    % frame-level ground truth
    ContourTimeStamp = validationSet(i_contour).F0time;
    validationSet(i_contour).GTFrame = convertToFrameLevel(GTStateSeg_matrix, ContourTimeStamp);

    
    %% evaluate performance of detection method on frame level
    % 
    % frame_level metrics
    groundTruth_frame = validationSet(i_contour).GTFrame(:,2);
    transcribed_frame = validationSet(i_contour).TrFrame(:,2);
    proportionCorrect(i_contour) = calculateFrameLevelAccuracy(groundTruth_frame, transcribed_frame);

    groundTruth_frame_all = [groundTruth_frame_all;groundTruth_frame];
    transcribed_frame_all = [transcribed_frame_all;transcribed_frame];

    %% evaluate performance of detection method on state level

    % state_level metrics
    transcribed_state = validationSet(i_contour).TrStateSeg; %(onset offset statelabel)
    groundTruth_state = validationSet(i_contour).GTStateSeg;
    % change label to positive fit to evaluation framework
    transcribed_state(:,3) = 88;
    groundTruth_state(:,3) = 88;
    % collect it into cell to fit evaluation framework
    transcribed_state_cell{i_contour} = transcribed_state;
    groundTruth_state_cell{i_contour} = groundTruth_state;
    

end

performance_frame_mean = mean(proportionCorrect);
performance_frame_var = var(proportionCorrect);

[performance_state_all,performance_state_key] = evaluation_pitch_contour(transcribed_state_cell,groundTruth_state_cell);

% Create confusion matrix
confusionMatrix = confusionmat(groundTruth_frame_all, transcribed_frame_all);
% Row-wise normalization
normalizedMatrixRow = bsxfun(@rdivide, confusionMatrix, sum(confusionMatrix, 2));


% Visualize the confusion matrix
imagesc(normalizedMatrixRow);
colorbar;
title('Confusion Matrix of States Classification in Frame Level');
xlabel('Predicted State');
ylabel('Actual State');
set(gca, 'XTick', 1:3, 'XTickLabel', {'Transitory', 'Steady', 'Modulation'});
set(gca, 'YTick', 1:3, 'YTickLabel', {'Transitory', 'Steady', 'Modulation'});

end

function StateSequence = correctShortModulated(StateSequence,Tr_quantum_length)
    count = 0; % 记录连续1的个数
    startIdx = 0; % 记录当前连续1段的起始位置

    % 遍历整个序列
    for i = 1:length(StateSequence)
        % 如果当前元素为1
        if StateSequence(i) == 1
            count = count + 1; % 增加计数
            if count == 1
                startIdx = i; % 标记段的开始
            end
        else
            % 如果段结束且长度小于 Tr_quantum_length
            if count > 0 && count < Tr_quantum_length
                StateSequence(startIdx:i-1) = -1; % 更改这个段的所有1为-1
            end
            count = 0; % 重置计数
        end
    end

    % 检查最后一个段
    if count > 0 && count < Tr_quantum_length
        StateSequence(startIdx:end) = -1;
    end
    
    % 返回修改后的序列
    return;
end




function StateSeg_matrix = mergeQuantumSegments(QuantumSeg_matrix)
    % Initialize the output matrix with the first row of the input matrix
    StateSeg_matrix = QuantumSeg_matrix(1,:);
    if size(QuantumSeg_matrix, 1)>1
        % Iterate through the QuantumSeg_matrix
        for i = 2:size(QuantumSeg_matrix, 1)
            currentSeg = QuantumSeg_matrix(i,:);
            lastSeg = StateSeg_matrix(end,:);

            % Check if the current segment can be merged with the last segment
            if currentSeg(3) == lastSeg(3)
                % Merge segments: Update the offset of the last segment
                StateSeg_matrix(end, 2) = currentSeg(2);
            else
                % Different state label, so add the current segment as a new row
                StateSeg_matrix = [StateSeg_matrix; currentSeg];
            end
        end
    end
end

function Frame_matrix = convertToFrameLevel(StateSeg_matrix, ContourTimeStamp)
    % Initialize Frame_matrix
    Frame_matrix = zeros(length(ContourTimeStamp), 2);
    
    % Assign time values to the first column of Frame_matrix
    Frame_matrix(:, 1) = ContourTimeStamp;
    
    % Iterate through each timestamp
    for i = 1:length(ContourTimeStamp)
        currentTime = ContourTimeStamp(i);

        % Find the segment that the current time belongs to
        for j = 1:size(StateSeg_matrix, 1)
            if currentTime >= StateSeg_matrix(j, 1) && currentTime <= StateSeg_matrix(j, 2)
                Frame_matrix(i, 2) = StateSeg_matrix(j, 3); % Assign statelabel
                break; % Exit the loop once the segment is found
            end
        end
    end
end