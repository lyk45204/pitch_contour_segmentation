function [accuracy_nor, accuracy_SD, precision, recall, F1Score] = calculateFrameMetrics(groundTruth, predictions)
    % Calculate True Positives (TP), False Positives (FP), True Negatives (TN), and False Negatives (FN)
    TP = sum((predictions == 1) & (groundTruth == 1));
    FP = sum((predictions == 1) & (groundTruth == 0));
    TN = sum((predictions == 0) & (groundTruth == 0));
    FN = sum((predictions == 0) & (groundTruth == 1));

    % Calculate Accuracy
    accuracy_nor = (TP + TN) / (TP + FP + TN + FN);
    accuracy_SD = (TP) / (TP + FP + FN);

    % Calculate Recall
    if (TP + FN) == 0
        recall = 0; % Prevent division by zero
    else
        recall = TP / (TP + FN);
    end

    % Calculate Precision
    if (TP + FP) == 0
        precision = 0; % Prevent division by zero
    else
        precision = TP / (TP + FP);
    end

    % Calculate F1 Score
    if (precision + recall) == 0
        F1Score = 0; % Prevent division by zero for F1 calculation
    else
        F1Score = 2 * (precision * recall) / (precision + recall);
    end
end
