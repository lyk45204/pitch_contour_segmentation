function [features, quanta] = extract_quantums_and_features(data, stateNames, labels)

transitory_cutoff = 1;%Hz 
steady_cutoff = 200; %Hz
vibrato_cutoff = 20; % Hz

    features = struct();
    quanta = struct('file', {}, 'state', {}, 'pitchtrack', {}, ...
        'onset', {}, 'offset', {}, 'dur', {}, 'pitchinterval', {}, 'fre', {}, 'extent', {});
    label_to_state = containers.Map(labels, stateNames);

    for i_files = 1:length(data)
        annotated_segments = data(i_files).State;
        file_pitchtrack = [data(i_files).F0time data(i_files).F0pitch];
        label_vector = annotated_segments(:,2); % -1, 0, 1, -2
        quantum_index = 1;

        for i_seg = 1:size(annotated_segments, 1)

            seg_onset = annotated_segments(i_seg, 1);
            seg_dur = annotated_segments(i_seg, 3);
            seg_offset = seg_onset + seg_dur;
            seg_pitchtrack = cell2mat(cutpitch(seg_onset, seg_offset, file_pitchtrack));
            CurLabel = label_vector(i_seg);

            % Determine the quantums in the segment
            switch CurLabel
                case -1 % transitory
                    num_quantums = 1;
                
                    quantum_onset = seg_onset;
                    quantum_offset = seg_offset; 
                    quantum_dur = seg_dur;
                    quantum_pitchtrack = seg_pitchtrack;


                    dur = quantum_dur;
                    pitchinterval = quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2);
                    fre = 1./(quantum_dur*2);
                    extent = pitchinterval./2;

                    quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                        'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                        'dur', dur, 'pitchinterval', pitchinterval, 'fre', fre, 'extent', extent);
                    quanta(end+1) = quantum;
                 

                case 0
                    MinPeakDistance = 0;
                    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
                    extremums_time = extremums(:,1);
                    num_quantums = size(extremums,1)-1;

                    for i_quantum = 1:num_quantums
                        % Extract features and details for each quantum
                        quantum_onset = extremums_time(i_quantum);
                        quantum_offset = extremums_time(i_quantum+1);
                        quantum_dur = quantum_offset - quantum_onset;
                        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

                        dur = quantum_dur;
                        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
                        fre = 1./(quantum_dur*2);
                        extent = pitchinterval./2;


                        % Assign quantum details in a more concise manner
                        quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                            'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                            'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                        quanta(end+1) = quantum;
                      
                    end
                case 1
                    MinPeakDistance = 0;
                    [peaks troughs extremums] = FindLocalextremumsFn(seg_pitchtrack(:,2),seg_pitchtrack(:,1),MinPeakDistance,1);
                    extremums_time = extremums(:,1);
                    num_quantums = size(extremums,1)-1;

                    for i_quantum = 1:num_quantums
                        % Extract features and details for each quantum
                        quantum_onset = extremums_time(i_quantum);
                        quantum_offset = extremums_time(i_quantum+1);
                        quantum_dur = quantum_offset - quantum_onset;
                        quantum_pitchtrack = cell2mat(cutpitch(quantum_onset, quantum_offset, seg_pitchtrack));

                        dur = quantum_dur;
                        pitchinterval = (quantum_pitchtrack(end,2)-quantum_pitchtrack(1,2));
                        fre = 1./(quantum_dur*2);
                        extent = pitchinterval./2;


                        % Assign quantum details in a more concise manner
                        quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                            'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                            'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                        quanta(end+1) = quantum;
                    

                    end
                case -2 % no quantum segmentation
                    num_quantums = 1;
                
                    quantum_onset = seg_onset;
                    quantum_offset = seg_offset; 
                    quantum_dur = seg_dur;
                    quantum_pitchtrack = seg_pitchtrack;

                    dur = [];
                    pitchinterval = [];
                    fre = [];
                    extent = [];
                    
                    quantum = struct('file', i_files, 'state', label_to_state(CurLabel), ...
                        'pitchtrack', quantum_pitchtrack, 'onset', quantum_onset, 'offset', quantum_offset, ...
                        'dur', dur, 'pitchinterval',pitchinterval,'fre', fre, 'extent', extent);
                    quanta(end+1) = quantum;
            end
        end

    end

   

    for i_quantum = 1:length(quanta)
        state = quanta(i_quantum).state;
        quantum_feature = [quanta(i_quantum).dur quanta(i_quantum).extent];
        fre = quanta(i_quantum).fre;
        % Check conditions for different states
        if ~strcmp(label_to_state(CurLabel),'noise')
            if (strcmp(state, 'transitory') && fre > transitory_cutoff) || ...
                    (strcmp(state, 'steady') && fre < steady_cutoff) || ...
                    (strcmp(state, 'modulation') && fre < vibrato_cutoff)
                % Update features structure
                if isfield(features, state)
                    features.(state) = [features.(state); quantum_feature];
                else
                    features.(state) = quantum_feature;
                end
            end
        end
    end

    
       
end