function pitchContourSegments = ExtractPitchContours(data,quanta)
    % Initialize the output structure
    pitchContourSegments = struct('F0time', {}, 'F0pitch', {}, 'Quantum', {}, 'QuantumNum', {}, 'Filename', {});

    % Process each file in the data
    for fileIdx = 1:length(data)
        fileIdx
        F0originalTime = data(fileIdx).OriPitch.time;

        F0time = data(fileIdx).F0time;
        F0pitch = data(fileIdx).F0pitch;
        % Find indices of quanta that belong to the specified file
        indices = find([quanta.file] == fileIdx);
        % Extract those quanta of the current file
        quantumData = quanta(indices);
        filename = data(fileIdx).Filename;

        % Find breaks in F0time to identify pitch contour segments
        delta_time = F0originalTime(2)-F0originalTime(1);
        breaks_Ori = find(diff(F0originalTime) > 1.2*delta_time);
        breaks_Time_end = F0originalTime(breaks_Ori);
        breaks_Time_start = F0originalTime(breaks_Ori+1);
        % set noises region as breaks
        noiseIndices = find(arrayfun(@(x) strcmp(x.state, 'noise'), quantumData));
        if ~isempty(noiseIndices)
            noise_quantum_onset = quantumData(noiseIndices).onset;
            noise_quantum_offset = quantumData(noiseIndices).offset;
            breaks_Time_end = [breaks_Time_end;noise_quantum_onset];
            breaks_Time_start = [breaks_Time_start;noise_quantum_offset];
        end



        breaks_loc_start = zeros(length(breaks_Time_start),1);
        breaks_loc_end = zeros(length(breaks_Time_end),1);

        for i_breaks = 1:length(breaks_loc_start)
            [v_min,breaks_loc_start(i_breaks)] = min( abs(breaks_Time_start(i_breaks)-F0time) );
            [v_min,breaks_loc_end(i_breaks)] = min( abs(breaks_Time_end(i_breaks)-F0time) );

        end

        segmentStarts = sort([1; breaks_loc_start]);
        segmentEnds = sort([breaks_loc_end; length(F0time)]);

        % Create segments
        for i_segment = 1:length(segmentStarts)
            i_segment
            startIdx = segmentStarts(i_segment); % ind of F0
            endIdx = segmentEnds(i_segment);
            
            % Initialize segment
            segment = struct();
            segment.F0time = F0time(startIdx:endIdx);
            segment.F0pitch = F0pitch(startIdx:endIdx);
            segment.Quantum = struct();
            segment.Filename = filename;

            % Find quanta within this segment's time range
            segmentStartTime = F0time(startIdx);
            segmentEndTime = F0time(endIdx);

            if ~isempty(quantumData)
                % Initialize segment.Quantum with the same fields as the first quantumData
                segment.Quantum = quantumData(1);
                segment.Quantum(1) = []; % Clear the initial content
            else
                error('no quantum in the segment %d in file %d',i_segment,fileIdx)
            end
            
            for j = 1:length(quantumData)
                quantumOnset = quantumData(j).onset;
                quantumOffset = quantumData(j).offset;

                if ~strcmp(quantumData(j).state,'noise' ) && ...
                        ((quantumOnset >= segmentStartTime && quantumOnset <= segmentEndTime) || ...
                        (quantumOffset >= segmentStartTime && quantumOffset <= segmentEndTime))
                    segment.Quantum(end+1) = quantumData(j);
                    
                end
            end
            segment.QuantumNum = length(segment.Quantum);

            % update the boundary of F0time and F0pitch of the pitch
            % contour to remove the silence region.
            if segment.QuantumNum>0
                quanta_in_seg = segment.Quantum;
                onset = quanta_in_seg(1).onset;
                offset = quanta_in_seg(end).offset;

                F0time_seg = segment.F0time;
                F0pitch_seg = segment.F0pitch;

                if F0time_seg(1)<onset
                    [~, onsetIdx] = min(abs(F0time_seg - onset));
                    F0time_seg = F0time_seg(onsetIdx:end);
                    F0pitch_seg = F0pitch_seg(onsetIdx:end);
                end
                if F0time_seg(end)>offset
                    [~, offsetIdx] = min(abs(F0time_seg - offset));
                    F0time_seg = F0time_seg(1:offsetIdx);
                    F0pitch_seg = F0pitch_seg(1:offsetIdx);
                end

                segment.F0time = F0time_seg;
                segment.F0pitch = F0pitch_seg;
            end

            % Append to output structure
            if segment.QuantumNum > 0 % ignore the silent pitch contour segment without annotation
                pitchContourSegments(end+1) = segment;
            end

        end
    end

   

    % Check if any pitchContourSegments share the same quantum region
    % If yes, display an error and show the numbers of the pitchContours and the shared state

    numSegments = length(pitchContourSegments);

    for i = 1:numSegments-1
%         i
            % Get the state regions for the current pair of segments
            Quantum_i = pitchContourSegments(i).Quantum;
            Quantum_j = pitchContourSegments(i+1).Quantum;

            % Check for shared states
            if Quantum_i(end).onset == Quantum_j(1).onset
                error('Shared Quantum found between segments %d and %d in file %d', i, i+1,fileIdx);
            end

    end

    
end