function [pitchContourSegments,num_silent_label] = ExtractPitchContours_no_quanta(data,labelname)
    % Initialize the output structure
    pitchContourSegments = struct('F0time', {}, 'F0pitch', {}, 'Filename', {}, ...
        'labelRegion',{}, 'labelRegionNum',{});

    % Process each file in the data
    for fileIdx = 1:length(data)
        fileIdx
        filename = data(fileIdx).Filename;
        F0originalTime = data(fileIdx).OriPitch.time;

        F0time = data(fileIdx).F0time;
        F0pitch = data(fileIdx).F0pitch;
        labelRegion = data(fileIdx).(labelname);
        

        % Find breaks in F0originalTime to identify pitch contour segments
        delta_time = F0originalTime(2)-F0originalTime(1);
        breaks_Ori = find(diff(F0originalTime) > 1.2*delta_time);
        breaks_Time_end = F0originalTime(breaks_Ori);
        breaks_Time_start = F0originalTime(breaks_Ori+1);

        % check how many label region cover silence region between two pitch contours
        num_silent_label = 0;
        for i_label = 1:size(labelRegion,1)
            onsetLabel = labelRegion(i_label,1);
            offsetLabel = labelRegion(i_label,2);
            for i_silence = 1:size(breaks_Time_end,1)
                onset_silence = breaks_Time_end(i_silence);
                offset_silence = breaks_Time_start(i_silence);
                if onsetLabel <= onset_silence & offsetLabel >= offset_silence
                    num_silent_label = num_silent_label + 1;
                end

            end

        end
       

 


        
        % Find breaks in F0time to identify pitch contour segments
        breaks_loc_start = zeros(length(breaks_Time_start),1);
        breaks_loc_end = zeros(length(breaks_Time_end),1);

        for i_breaks = 1:length(breaks_loc_start)
            [v_min,breaks_loc_start(i_breaks)] = min( abs(breaks_Time_start(i_breaks)-F0time) );
            [v_min,breaks_loc_end(i_breaks)] = min( abs(breaks_Time_end(i_breaks)-F0time) );

        end

        segmentStarts = sort([1; breaks_loc_start]);
        segmentEnds = sort([breaks_loc_end; length(F0time)]);

        % Create segments
        for i_segment = 1:length(segmentStarts)
            i_segment
            startIdx = segmentStarts(i_segment); % ind of F0
            endIdx = segmentEnds(i_segment);
            
            % Initialize segment
            segment = struct();
            segment.F0time = F0time(startIdx:endIdx);
            segment.F0pitch = F0pitch(startIdx:endIdx);
            segment.Filename = filename;

            % get the label region in this pitch contour segment
            segmentStartTime = F0time(startIdx);
            segmentEndTime = F0time(endIdx);

            if ~isempty(labelRegion)
                % Initialize segment.Quantum with the same fields as the first quantumData
                % segment.labelRegion = labelRegion(1);
                segment.labelRegion = []; % Clear the initial content
            else
                error('no quantum in the segment %d in file %d',i_segment,fileIdx)
            end
            
            for j = 1:length(labelRegion)
                labelRegionOnset = labelRegion(j,1);
                labelRegionOffset = labelRegion(j,2);

                if  ((labelRegionOnset >= segmentStartTime && labelRegionOnset <= segmentEndTime) || ...
                        (labelRegionOffset >= segmentStartTime && labelRegionOffset <= segmentEndTime))
                    segment.labelRegion = [segment.labelRegion; labelRegion(j,:)];

                end
            end

            labelRegion_in_seg = segment.labelRegion;
            segment.labelRegionNum = size(labelRegion_in_seg,1);

            % Update the the boundary of labeled regions in the segment
            if ~isempty(labelRegion_in_seg)
                F0time_seg = segment.F0time; % Get the time series of the pitch segment

                % Update the labelRegion to ensure that the onset is after the start of F0time_seg
                if labelRegion_in_seg(1, 1) < F0time_seg(1)
                    labelRegion_in_seg(1, 1) = F0time_seg(1);
                    % delete short region
                    durLabel = labelRegion_in_seg(1,2) - labelRegion_in_seg(1,1);
                    if durLabel < 0.05
                        labelRegion_in_seg(1,:) = []; %
                    end
                end

                % Update the labelRegion to ensure that the offset is before the end of F0time_seg
                if ~isempty(labelRegion_in_seg)
                    if labelRegion_in_seg(end, 2) > F0time_seg(end)
                        labelRegion_in_seg(end, 2) = F0time_seg(end);
                        % delete short region
                        durLabel = labelRegion_in_seg(end,2) - labelRegion_in_seg(end,1);
                        if durLabel < 0.05
                            labelRegion_in_seg(end,:) = []; %
                        end
                    end
                end


                % Assign the updated labelRegion back to the segment
                segment.labelRegion = labelRegion_in_seg;

            end


            % Append to output structure
            pitchContourSegments(end+1) = segment;

        end
    end



    
   
end