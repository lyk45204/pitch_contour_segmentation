function data = readSteadyRegionFn(filePath,data)
% input: M : onset, offset, duration
% output: onset offset duration
global data;
fileInf = dir2(filePath);
 %% ignore folders and DS_Store file
    IgnoreFiles = [];
    n_files = length(fileInf);
    for i = 1:n_files
        if strcmp(fileInf(i).name,'.DS_Store')
            IgnoreFiles = [IgnoreFiles;i];
            
        end
        if fileInf(i).isdir
            IgnoreFiles = [IgnoreFiles;i];

        end

    end
    fileInf([IgnoreFiles]) = [];
%% read

n_files = length(fileInf);
for i_files = 1:n_files
    fileNameSuffix = fileInf(i_files).name;
    if isnumeric(fileNameSuffix) == 0
        fullPathName = strcat(filePath,fileNameSuffix);
        [filepath,name,extension] = fileparts(fullPathName);
        [SteadyPitchTrack] = readmatrix(fullPathName); % onset offset duration

        n = size(SteadyPitchTrack, 1); % number of frame
        stableRegions = [];
        isInStableRegion = false;
        onset = 0;
        offset = 0;

        for i = 1:n
            if SteadyPitchTrack(i, 2) > 0
                if ~isInStableRegion
                    isInStableRegion = true;
                    onset = SteadyPitchTrack(i, 1);
                    onsetframe = i;
                end
            else
                if isInStableRegion
                    isInStableRegion = false;
                    offset = SteadyPitchTrack(i-1, 1);
                    offsetframe = i-1
                    medianPitch = median(SteadyPitchTrack(onsetframe:offsetframe, 2));
                    stableRegions = [stableRegions; onset, offset, medianPitch];
                end
            end
        end

        % Check for the last stable region if the loop ends while still in a stable region
        if isInStableRegion
            offset = SteadyPitchTrack(end, 1);
            medianPitch = freqToMidi( median(SteadyPitchTrack(i:end, 2)) );
            stableRegions = [stableRegions; onset, offset, medianPitch];
        end


        % remove the region less than 50ms to correct the annotation
        % errors.
        dur = stableRegions(2)-stableRegions(1);
        idx_short_region = find(dur<0.05);
        stableRegions(idx_short_region,:) = [];
        
        % change duration to statelabel
        stableRegions = [stableRegions stableRegions(:,3)];
        stableRegions(:,3) = 0;
      
        data(i_files).StableRegions = stableRegions;
        
    end
end