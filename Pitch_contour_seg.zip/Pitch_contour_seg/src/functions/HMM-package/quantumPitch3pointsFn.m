function [pitchstart,pitchend,pitchmiddle] = quantumPitch3pointsFn(quantum,number)

pitchstart = quantum.pitchStart(number); 
pitchend = pitchstart + quantum.pitchInterval(number);
pitchmiddle = (pitchstart + pitchend)/2;