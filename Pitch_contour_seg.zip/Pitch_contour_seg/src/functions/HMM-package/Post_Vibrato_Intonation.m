function [vibratoSeg] = Post_Vibrato_Intonation(QuantumSeg_matrix,quanta,quantumCriterion)

% input:
%   quanta: quanta(i).onset/offset/dur/pitchinterval/pitchtrack
% output:
%   vibratoSegments: onset offset indicator(1)


    % Initialize the updatedMatrix with the input matrix
    updatedMatrix = QuantumSeg_matrix; % onset offset indicator
    
    % Initialize the array to hold vibrato segments
    vibratoSegments_idx = []; % onset offset
    
    % Get the number of quanta
    numQuanta = size(QuantumSeg_matrix, 1);
    
    % Loop through the quanta in pairs
    for i = 1:numQuanta-1

        % Extract consecutive 3 quanta
        quantum1 = quanta(i);
        quantum2 = quanta(i+1);
        

        if QuantumSeg_matrix(1,3) == 1 && QuantumSeg_matrix(2,3) == 1 

            % extract the pitch start and end of quantum 1 and 3
            quantum1_pitchstart = quantum1.pitchtrack(1,2);
            quantum1_pitchend = quantum1.pitchtrack(end,2);
            quantum2_pitchstart = quantum2.pitchtrack(1,2);
            quantum2_pitchend = quantum2.pitchtrack(end,2);


            % Calculate the midpoint pitch value of each quantum
            midpoint1 = (quantum1_pitchstart + quantum1_pitchend) / 2;
            midpoint2 = (quantum2_pitchstart + quantum2_pitchend) / 2;

            % decide the small and big of quantum3
            if quantum2_pitchstart < quantum2_pitchend
                quantum2_pitchsmall = quantum2_pitchstart;
                quantum2_pitchbig = quantum2_pitchend;
            else
                quantum2_pitchsmall = quantum2_pitchend;
                quantum2_pitchbig = quantum2_pitchstart;

            end
            
            % Check if midpoint pitch of quantum1 is within the range of quantum2
            
            if ~(quantum2_pitchsmall <= midpoint1 && midpoint1 <= quantum2_pitchbig)
                updatedMatrix(i,3) = -1; % Update indicator to transitory
            else
                vibratoSegments_idx = [vibratoSegments_idx;i]; % Add to vibrato segments
            end

            % % decide the small and big of quantum1
            % if quantum1_pitchstart < quantum1_pitchend
            %     quantum1_pitchsmall = quantum1_pitchstart;
            %     quantum1_pitchbig = quantum1_pitchend;
            % else
            %     quantum1_pitchsmall = quantum1_pitchend;
            %     quantum1_pitchbig = quantum1_pitchstart;
            % 
            % end
            % 
            % % Check if midpoint pitch of quantum3 is within the range of quantum1
            % if ~(quantum1_pitchsmall <= midpoint3 && midpoint3 <= quantum1_pitchbig)
            %     updatedMatrix(i+2,3) = -1; % Update indicator to transitory
            % else
            %     vibratoSegments_idx = [vibratoSegments_idx;i+2]; % Add to vibrato segments
            % end
        end
    end


% merge quantum as vibrato
% Initialize an empty array for vibrato segments
vibratoSeg = [];

% Start with the first vibrato index
if ~isempty(vibratoSegments_idx)
    startIdx = vibratoSegments_idx(1);
    endIdx = startIdx;
    count = 1; % Counter for consecutive vibrato quanta

    % Loop through all vibrato indices to merge consecutive segments
    for i = 2:length(vibratoSegments_idx)
        % Check if the current index is consecutive
        if vibratoSegments_idx(i) == endIdx + 1
            endIdx = vibratoSegments_idx(i);
            count = count + 1;
        else
            % If the current index is not consecutive, end the current vibrato region
            % and check if it contains 3 or more quanta
            if count >= quantumCriterion
                vibratoSeg = [vibratoSeg; updatedMatrix(startIdx, 1), updatedMatrix(endIdx, 2), 1];
            end
            % Start a new vibrato region
            startIdx = vibratoSegments_idx(i);
            endIdx = startIdx;
            count = 1;
        end
    end

    % Check the last vibrato region
    if count >= quantumCriterion
        vibratoSeg = [vibratoSeg; updatedMatrix(startIdx, 1), updatedMatrix(endIdx, 2), 1];
    end
end

end


